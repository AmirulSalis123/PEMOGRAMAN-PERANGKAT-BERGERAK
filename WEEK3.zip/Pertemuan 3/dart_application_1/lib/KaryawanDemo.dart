import 'Karyawan_tetap.dart';
import 'KaryawanKontrak.dart';

void main() {
  KaryawanTetap tetap = KaryawanTetap("T001", "Agus", gajiPokok: 5000000);

  KaryawanKontrak kontrak = KaryawanKontrak("K001", "Slamet",
      upahHarian: 150000, jumlahHariMasuk: 22);

  print('================ KARYAWAN TETAP ================');
  print(tetap.deskripsi());

  print('============== KARYAWAN KONTRAK ================');
  print(kontrak.deskripsi());
}
