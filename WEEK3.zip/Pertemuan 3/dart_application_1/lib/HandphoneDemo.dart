import 'Handphone.dart';

void main() {
  // Membuat objek Handphone
  Handphone hp = new Handphone();

  // Mengatur nilai properti
  hp.setNomor(111202214258);
  hp.setPixel(12.5); // Mengatur pixel (implementasi Kamera)
  hp.setGelombang('FM 98.7'); // Mengatur gelombang (implementasi Radio)

  // Memanggil metode
  print('Status Telepon:');
  hp.telpon(); // Dari kelas Telepon (extends)

  print('\nFitur Kamera:');
  hp.ambilGambar(); // Dari interface Kamera (implements)
  print('Pixel Kamera: ${hp.pixel} MP');

  print('\nFitur Radio:');
  print(
      'Gelombang Radio: ${hp.gelombang}'); // Dari interface Radio (implements)
}
