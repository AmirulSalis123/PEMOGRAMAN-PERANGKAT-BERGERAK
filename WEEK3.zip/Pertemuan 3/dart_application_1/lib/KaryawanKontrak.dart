import 'Karyawan.dart';

class KaryawanKontrak extends Karyawan {
  double upahHarian;
  int jumlahHariMasuk;

  KaryawanKontrak(String npp, String nama,
      {int thnMasuk = 2015,
      required this.upahHarian,
      required this.jumlahHariMasuk})
      : super(npp, nama, thnMasuk: thnMasuk);

  @override
  double hitungTotalGaji() {
    double totalUpahKerja = upahHarian * jumlahHariMasuk;
    return totalUpahKerja + tunjanganAnak;
  }

  @override
  String deskripsi() {
    return '''
${super.deskripsi()}
Status: Karyawan Kontrak
Upah Harian: $upahHarian
Hari Masuk: $jumlahHariMasuk
Tunjangan Anak: $tunjanganAnak
Total Upah: ${hitungTotalGaji()}
''';
  }
}
