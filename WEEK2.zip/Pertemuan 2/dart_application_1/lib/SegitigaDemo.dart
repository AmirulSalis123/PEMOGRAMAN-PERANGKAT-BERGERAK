import 'Segitiga.dart';

void main() {
  Segitiga s = new Segitiga(10, 5, 7, 8, 9);

  double luas = s.getLuas();
  int keliling = s.getKeliling();

  print('Luas Segitiga : $luas');
  print('Keliling Segitiga : $keliling');
}
