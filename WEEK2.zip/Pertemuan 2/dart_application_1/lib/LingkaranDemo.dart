import 'Lingkaran.dart';

void main() {
  Lingkaran l = new Lingkaran(7.0);

  double luas = l.getLuas();
  double keliling = l.getKeliling();

  print('Luas Lingkaran : $luas');
  print('Keliling Lingkaran : $keliling');
}
