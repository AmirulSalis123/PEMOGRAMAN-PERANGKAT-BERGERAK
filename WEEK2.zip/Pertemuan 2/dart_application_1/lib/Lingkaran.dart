import 'dart:math';

class Lingkaran {
  double r = 0;

  Lingkaran(double jariJari) {
    this.r = jariJari;
  }

  double getLuas() {
    return pi * r * r;
  }

  double getKeliling() {
    return 2 * pi * r;
  }
}
