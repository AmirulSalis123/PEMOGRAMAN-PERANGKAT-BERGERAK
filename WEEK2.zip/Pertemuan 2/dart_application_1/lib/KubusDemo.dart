import 'Kubus.dart';

void main() {
  Kubus k = new Kubus(5);

  int volume = k.getVolume();
  int luasPermukaan = k.getLuasPermukaan();

  print('Volume Kubus : $volume');
  print('Luas Permukaan Kubus : $luasPermukaan');
}
