import 'Nilai.dart';

void main() {
  nilaiPPB nilaiku = new nilaiPPB();
  nilaiku.inputmhs();
  nilaiku.hitungnilai();
  nilaiku.cetakNilai();
}
