class Segitiga {
  int a = 0;
  int t = 0;
  int s1 = 0;
  int s2 = 0;
  int s3 = 0;

  Segitiga(int alas, int tinggi, int sisi1, int sisi2, int sisi3) {
    this.a = alas;
    this.t = tinggi;
    this.s1 = sisi1;
    this.s2 = sisi2;
    this.s3 = sisi3;
  }

  double getLuas() {
    return 0.5 * a * t;
  }

  int getKeliling() {
    return s1 + s2 + s3;
  }
}
