import 'dart:io';
import 'dart:math';

void main() {
  // Persegi (Square)
  print("--- Persegi (Square) ---");
  print("Masukkan sisi: ");
  double sisiPersegi = double.parse(stdin.readLineSync()!);
  double luasPersegi = hitungLuasPersegi(sisiPersegi);
  double kelilingPersegi = hitungKelilingPersegi(sisiPersegi);
  print("Luas Persegi: $luasPersegi");
  print("Keliling Persegi: $kelilingPersegi");

  print("\n");

  // Lingkaran (Circle)
  print("--- Lingkaran (Circle) ---");
  print("Masukkan jari-jari: ");
  double jariJariLingkaran = double.parse(stdin.readLineSync()!);
  double luasLingkaran = hitungLuasLingkaran(jariJariLingkaran);
  double kelilingLingkaran = hitungKelilingLingkaran(jariJariLingkaran);
  print("Luas Lingkaran: $luasLingkaran");
  print("Keliling Lingkaran: $kelilingLingkaran");

  print("\n");

  // Kubus (Cube)
  print("--- Kubus (Cube) ---");
  print("Masukkan sisi: ");
  double sisiKubus = double.parse(stdin.readLineSync()!);
  double luasPermukaanKubus = hitungLuasPermukaanKubus(sisiKubus);
  double volumeKubus = hitungVolumeKubus(sisiKubus);
  print("Luas Permukaan Kubus: $luasPermukaanKubus");
  print("Volume Kubus: $volumeKubus");
}

// Function to calculate the area of a square
double hitungLuasPersegi(double sisi) {
  return sisi * sisi;
}

// Function to calculate the perimeter of a square
double hitungKelilingPersegi(double sisi) {
  return 4 * sisi;
}

// Function to calculate the area of a circle
double hitungLuasLingkaran(double jariJari) {
  return pi * jariJari * jariJari;
}

// Function to calculate the perimeter (circumference) of a circle
double hitungKelilingLingkaran(double jariJari) {
  return 2 * pi * jariJari;
}

// Function to calculate the surface area of a cube
double hitungLuasPermukaanKubus(double sisi) {
  return 6 * sisi * sisi;
}

// Function to calculate the volume of a cube
double hitungVolumeKubus(double sisi) {
  return sisi * sisi * sisi;
}
