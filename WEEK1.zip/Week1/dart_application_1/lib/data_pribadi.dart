void main() {
  String nim = "A11.2022.14258";
  String nama = "Amirul Salis";
  String alamat = "Jalan nakula raya no 66";
  String kota = "Semarang";
  String kodePos = "50131";
  String telp = "082133960425";
  String hp = "082133960425";
  String email = "111202214258@mhs.dinus.ac.id.com";

  print("Nim           : $nim");
  print("Nama          : $nama");
  print("Alamat        : $alamat");
  print("Kota          : $kota");
  print("Kode Pos      : $kodePos");
  print("No Telephone  : $telp");
  print("No HP         : $hp");
  print("Email         : $email");
}
