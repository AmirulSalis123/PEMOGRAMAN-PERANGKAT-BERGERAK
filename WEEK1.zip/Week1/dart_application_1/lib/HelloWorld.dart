void main() {
  Mahasiswa mhs = new Mahasiswa();
  mhs.nim = 'A11.2022.14258';
  mhs.nama = 'Amirul Salis';
  mhs.IPK = 3.38;
  mhs.view();
}

class Mahasiswa {
  String nim = "", nama = "";
  double IPK = 0;
  Mahasiwa() {
    print('~~Data Mahasiswa~~');
  }

  void view() {
    print('Nim   : $nim');
    print('Nama  : $nama');
    print('IPK   : $IPK');
  }
}
