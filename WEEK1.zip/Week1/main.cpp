#include <iostream>

using namespace std;

int main()
{
    cout << "Nama         : Amirul Salis" << endl;
    cout << "Nim          : A11.2022.142158" << endl;
    cout << "Alamat       : Ds. Gemulung Rt 03 Rw 01 Kec. Pecangaan Kab. Jepara" << endl;
    cout << "Asal Sekolah : SMA WALISONGO PECANGAAN" << endl;
    return 0;
}
